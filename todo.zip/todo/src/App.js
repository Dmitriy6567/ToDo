import React from 'react';
import WrapperToDo from './components/WrapperToDo';
import './styles/App.css'

function App() {

  return (
    
      <div className="App">
        <WrapperToDo/>
      </div>
  );
}

export default App;
