import React from "react";
import '../styles/Button.css'

const Button = ({body,onClick}) =>{

    return(
        <button onClick={onClick} className="btn">{body}</button>
    )
}

export default Button;