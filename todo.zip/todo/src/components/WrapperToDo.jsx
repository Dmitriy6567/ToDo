import React,{useState} from "react";
import AddTask from "../components/AddTask";
import FilterTasks from "../components/FilterTasks";
import Header from "../components/Header";
import Tasks from "../components/Tasks";

export const allPosts = React.createContext()


const WrapperToDo = () => {

    const [posts, setPosts] = useState([
        {id:1,body:'Дело 1',check: false ,date:'03/07/22'},
        {id:2,body:'Дело 2',check: false ,date:'08/07/22'}
      ])

      function setPostsContext(){
        setPosts(posts)
      }

    return(
        <allPosts.Provider value={{posts,setPosts}}>
        <div>
            <Header/>
            <AddTask  cont={setPostsContext}/>
            <FilterTasks/>
            <Tasks/>
        </div>
        </allPosts.Provider>
    )
}

export default WrapperToDo;