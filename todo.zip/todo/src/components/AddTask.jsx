import React,{useState,useContext} from "react";
import '../styles/AddTask.css'
import Button from "./Button";
import Input from "./Input";
import { allPosts } from "./WrapperToDo";


const AddTask = ({setPostsContext}) => {
    
    const context = useContext(allPosts)
    console.log(allPosts)
    const [task,setTask] = useState('');

    function addNewPost(){
        const newPost = {
            id: Date.now(),
            task,
            date: new Date().getDate()
        }
        setPostsContext([...context,newPost])
        console.log(task)
    }

    return(
        <div className="add__task">
            <Input type={'text'} placeholder={'I want to...'} classStyle={'inp'} value={task} onChange={setTask} />
            <Button body={'Add'} onClick={addNewPost}/>
            <Button body={'Clear'}/>
        </div>
    )
}

export default AddTask;