import React from "react";
import "../styles/Input.css";

const Input = ({ type, placeholder, classStyle,value,onChange }) => {
  
  return <input type={type} className={classStyle} placeholder={placeholder} value={value} onChange={e=>onChange(e.target.value)}/>;
};

export default Input;
