import React from "react";
import ListItem from "./ListItem";
import '../styles/PostList.css'

const PostList = () => {

    return(
        <ul className="post__list">
            {/* <ListItem task={"Дело 1"} date={"13/06/22"}/>
            <hr/>
            <ListItem task={"Дело 2"} date={"13/06/22"}/>
            <hr/>
            <ListItem task={"Дело 3"} date={"13/06/22"}/>
            <hr/> */}
        </ul>
    )
}

export default PostList;